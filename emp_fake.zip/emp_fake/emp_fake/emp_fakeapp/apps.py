from django.apps import AppConfig


class EmpFakeappConfig(AppConfig):
    name = 'emp_fakeapp'

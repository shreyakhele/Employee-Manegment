from django.shortcuts import render
from django.http import HttpResponse
import faker
fake = faker.Faker()
from .models import empdata
# Create your views here.

def empdata_view(request):
    for i in range(500):
        first_name=fake.first_name()
        last_name=fake.last_name()
        email=fake.email()
        address=fake.address()
        salary=fake.random_element(elements = (10000,20000,30000))
        job=fake.random_element(elements = ('gov','private','teaching'))
        company=fake.random_element(elements =('tcs','nth','imposis'))
        location=fake.random_element(elements = ('hyd','banglore','pune'))
    empdata(
        first_name=first_name,
        last_name=last_name,
        email=email,
        address=address,
        salary=salary,
        job=job,
        company=company,
        location=location
    ).save()
    return HttpResponse('data saveed')
def feaching_data(request):
    emp=empdata.object.all()
    return render(request,'allempdata.html',{'emp':emp})
